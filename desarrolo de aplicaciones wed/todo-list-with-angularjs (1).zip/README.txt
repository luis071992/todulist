A Pen created at CodePen.io. You can find this one at http://codepen.io/Russbrown/pen/IgBuh.

 A very basic todo app I made messing around with angular JS